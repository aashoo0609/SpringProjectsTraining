package com.yash.test;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.verification.checkers.NonGreedyNumberOfInvocationsInOrderChecker;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;

import com.yash.controller.StudentController;
import com.yash.model.StudentRegisteredResponse;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
import com.yash.service.StudentService;



@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:applicationContext.xml"})
public class TestStudentControllerMock {

	private MockMvc mockMVC;
	
	@Mock
	private StudentService studService;
	
    @InjectMocks
	private StudentController studController;
    
    @Before
    public void init()
    {
    	MockitoAnnotations.initMocks(this);
    	mockMVC = MockMvcBuilders.standaloneSetup(studController).build(); 
    }
    
    @Test
    public void test_retriveAllStudents_positive()
    {
    	try{
    	List<StudentResponse> studResponseList = new ArrayList<StudentResponse>();
    	
    	StudentResponse studResponse = new StudentResponse();
    	studResponse.setRollno(1001);
    	studResponse.setName("YAsh");
    	studResponse.setAddress("Magarpatta");
    	
    	studResponseList.add(studResponse);
    	
    	when(studService.studentRetrievalService()).thenReturn(studResponseList);
    	
    	ResponseEntity<List<StudentResponse>> response = studController.retriveAllStudent();
    	List<StudentResponse> studList = response.getBody();
    	assertEquals(true, studList.size() > 0);
    	}catch(NullPointerException npe)
    	{
    		assertTrue(false);
    	}
    }
    
    @Test
    public void test_retriveAllStudents_positive_data_test()
    {
    	try{
    		List<StudentResponse> studResponseList = new ArrayList<>();
    		
    		StudentResponse studResponse = new StudentResponse();
    		studResponse.setRollno(2307);
    		studResponse.setName("HCL");
    		studResponse.setAddress("Hinjewadi");
    		
    		studResponseList.add(studResponse);
    		
    		when(studService.studentRetrievalService()).thenReturn(studResponseList);
    		
    		ResponseEntity<List<StudentResponse>> response = studController.retriveAllStudent();
    		List<StudentResponse> studList = response.getBody();
    		assertEquals(2307, studList.get(0).getRollno());
    		
    	}catch(IndexOutOfBoundsException ie)
    	{
    		assertTrue(false);
    	}
    }
	
    
    @Test
    public void test_retriveAllStudents_negative()
    {
    	
    		List<StudentResponse> studResponseList = new ArrayList<>();
    		
    		when(studService.studentRetrievalService()).thenReturn(studResponseList);
    		
    		ResponseEntity<List<StudentResponse>> response = studController.retriveAllStudent();
    		
    		List<StudentResponse> studList = response.getBody();
    	
    		StudentResponse studResponse = new StudentResponse();
    		studResponse.setRollno(1);
    		studResponse.setName("test");
    		studResponse.setAddress("test");
    		try{
    			when(studList.get(0).getRollno() == studResponse.getRollno());
    			assertTrue(false);
   		
    		}catch(IndexOutOfBoundsException ie)
    		{
    			assertTrue(true);
    		}
    }
    
    @Test
    public void test_persistStudent_positive()
    {
    	try{
    		StudentRequest studRequest = new StudentRequest();
    		studRequest.setRollno(14);
    		studRequest.setName("aaaaa");
    		studRequest.setAddress("pppppp");
    		
    		Errors errors = new BeanPropertyBindingResult(studRequest,"studRequest");
    		
    		
    		when(studService.studentRegistrationService(studRequest)).thenReturn(true);
    		
    		ResponseEntity<StudentRegisteredResponse> response = studController.persistStudent(studRequest, errors);
    		
    		StudentRegisteredResponse studRegResponse = response.getBody();
    		
    		assertEquals("Registered", studRegResponse.getResponseMsg());
    	}catch(Exception e)
    	{
    		assertTrue(false);
    	}
    }
    
    @Test
    public void test_persistStudent_nagative_validation()
    {
    	try{
    		StudentRequest studRequest = new StudentRequest();
    		studRequest.setRollno(1456);
    		studRequest.setName("aaaaa");
    		studRequest.setAddress("pppppp");
    		
    		Errors mockError = Mockito.mock(Errors.class);
    		
    		when(mockError.hasErrors()).thenReturn(true);
    		
    		when(studService.studentRegistrationService(studRequest)).thenReturn(false);
    		
    		ResponseEntity<StudentRegisteredResponse> response = studController.persistStudent(studRequest, mockError);
    		
    		StudentRegisteredResponse studRegResponse = response.getBody();
    		
    		assertEquals("Validation Error", studRegResponse.getResponseMsg());
    	}catch(Exception e)
    	{
    		assertTrue(false);
    	}
    }
    /////////////////////////////////////////////////
 /*   @Test
    public void test_persistStudent_positive_validation()
    {
    	try{
    		StudentRequest studRequest = new StudentRequest();
    		studRequest.setRollno(1456);
    		studRequest.setName("aaaaa");
    		studRequest.setAddress("pppppp");
    		
    		Errors mockError = Mockito.mock(Errors.class);
    		when(mockError.hasErrors()).thenReturn(true);
    		
    		List<ObjectError> objErrorList = new ArrayList<>();
    		ObjectError objError = new ObjectError("Validation Error", "student name not be blank");
    		
    		objErrorList.add(objError);
    		when(mockError.getAllErrors()).thenReturn(objErrorList);
    		
    		//when(studService.studentRegistrationService(studRequest)).thenReturn(false);
    		
    		ResponseEntity<StudentRegisteredResponse> response = studController.persistStudent(studRequest, mockError);
    		
    		StudentRegisteredResponse studRegResponse = response.getBody();
    		
    		assertEquals("Validation Error", studRegResponse.getResponseMsg());
    	}catch(Exception e)
    	{
    		assertTrue(false);
    	}
    }*/
}
