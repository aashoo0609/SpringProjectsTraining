package com.yash.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class RollNoValidator implements ConstraintValidator<RollNoConstraints, Integer> {

	@Override
	public boolean isValid(Integer value, ConstraintValidatorContext context) {
	
		String rollno = String.valueOf(value);
		if(rollno.length() < 3)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

}
