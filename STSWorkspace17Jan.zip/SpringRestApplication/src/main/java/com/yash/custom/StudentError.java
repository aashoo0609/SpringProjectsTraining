package com.yash.custom;

public class StudentError {
	private CustomHttpStatus errorCode;
	private String msg;
	
	public StudentError() {}
	public CustomHttpStatus getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(CustomHttpStatus errorCode) {
		this.errorCode = errorCode;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	

}
