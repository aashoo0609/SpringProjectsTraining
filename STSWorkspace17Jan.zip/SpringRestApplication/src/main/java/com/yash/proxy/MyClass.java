package com.yash.proxy;

public class MyClass {
	
	public MyClass() {
		System.out.println("MyClass Const..");
	}
	public String x(String str)
	{
		return str;
	}

}
