package com.yash.proxy;

import org.springframework.cglib.proxy.Enhancer;
import org.springframework.cglib.proxy.NoOp;
public class ProxyObject {
	
	public Object createProxy(Class targetClass)
	{
		Enhancer enhancer = new Enhancer();
		enhancer.setSuperclass(targetClass);
		enhancer.setCallback(NoOp.INSTANCE);
		
		return enhancer.create();
	}
	public static void main(String[] args) {
		ProxyObject proxyObject = new ProxyObject();
		MyClass mc = (MyClass) proxyObject.createProxy(MyClass.class);
		System.out.println(mc.x("sabbir"));
	}

}
