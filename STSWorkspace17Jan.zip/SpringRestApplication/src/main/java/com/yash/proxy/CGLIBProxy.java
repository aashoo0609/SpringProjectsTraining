package com.yash.proxy;

import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.FixedValue;

public class CGLIBProxy {

	public static void main(String[] args) {
		Enhancer enhancer = new Enhancer();
		enhancer.setSuperclass(MyClass.class);
		enhancer.setCallback(new FixedValue() {
			
			@Override
			public Object loadObject() throws Exception {
				
				return "sabbir";
			}
		});
		MyClass proxy = (MyClass) enhancer.create();
		
		String result = proxy.x("java");
		System.out.println(result);
		
		///////////////////////////////////////////////////////////
		Enhancer enhancer1 = new Enhancer();
		enhancer1.setSuperclass(MyInterface.class);
		enhancer1.setCallback(new FixedValue() {
			
			@Override
			public Object loadObject() throws Exception {
				
				return "sabbir12";
			}
		});
		MyInterface proxyInterf = (MyInterface) enhancer1.create();
		
		String result1 = proxyInterf.y("java");
		System.out.println(result1);
		
	}

}
