package com.yash.model;

import java.util.List;

import com.yash.custom.StudentError;

public class StudentRegisteredResponse {
	private StudentResponse responseData;
	public StudentResponse getResponseData() {
		return responseData;
	}
	public void setResponseData(StudentResponse responseData) {
		this.responseData = responseData;
	}
	private String responseMsg;
	private List<StudentError> studentError;
	
	public String getResponseMsg() {
		return responseMsg;
	}
	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}
	public List<StudentError> getStudentError() {
		return studentError;
	}
	public void setStudentError(List<StudentError> studentError) {
		this.studentError = studentError;
	}
	
}
