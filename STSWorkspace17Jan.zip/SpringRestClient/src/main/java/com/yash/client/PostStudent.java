package com.yash.client;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.yash.custom.StudentError;
import com.yash.handler.StudentErrorHandler;
import com.yash.model.StudentRegisteredResponse;

public class PostStudent {

	public static void main(String[] args) {
		RestTemplate template = new RestTemplate();
		template.setErrorHandler(new StudentErrorHandler());
		StudentRequest student = new StudentRequest();
		student.setRollno(13374);
		student.setName("Hemantttt");
		student.setAddress("MumbaiPune");
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		HttpEntity<String> requestEntity = new HttpEntity<String>(headers);
		String url = "http://localhost:8082/student-app/students";
		
		StudentRegisteredResponse response = template.postForObject(url,student,StudentRegisteredResponse.class);
		
		System.out.println("Message::"+response.getResponseMsg());
		List<StudentError> lstError = response.getStudentError();
		for(StudentError error : lstError)
		{
			System.out.println(error);
		}
	//System.out.println(response);
		

	}

}
