package com.yash.Integrate;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ConnectionManager {

	@Autowired
	private DataSource dataSource;
	
	public Connection openCon() throws ClassNotFoundException, SQLException
	{
		Class.forName(dataSource.getDriver());
		Connection con=DriverManager.getConnection(dataSource.getUrl(),dataSource.getUsername(),dataSource.getPassword());
		return con;
	}
}
