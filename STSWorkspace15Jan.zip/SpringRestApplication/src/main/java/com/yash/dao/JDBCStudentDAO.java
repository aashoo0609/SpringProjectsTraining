package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.yash.Integrate.ConnectionManager;
import com.yash.entity.Student;
import com.yash.exception.StudentDAOException;
import com.yash.model.StudentResponse;

@Repository
public class JDBCStudentDAO  implements StudentDAO{

	@Autowired
	private ConnectionManager manager;
	@Override
	public List<Student> getAllStudents() throws StudentDAOException {
		Connection connect;
		List<Student> studentList = null;
		try {
			connect = manager.openCon();
			Statement stmt =  connect.createStatement();
			ResultSet resultSet = stmt.executeQuery("select * from student");
			studentList = new ArrayList<>();
			while(resultSet.next())
			{
				Student stud = new Student();
				stud.setRollno(resultSet.getInt("rollno"));
				stud.setName(resultSet.getString("name"));
				stud.setAddress(resultSet.getString("address"));
				studentList.add(stud);
			}
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new StudentDAOException(e, "Data Access Exception");
		}
		
		return studentList;
	}
	@Override
	public Student getStudentByRollNo(int rollno) throws StudentDAOException {
	
		Student stud = new Student();
		try {
			Connection connect = manager.openCon();
			PreparedStatement pstmt = connect.prepareStatement("select * from student where rollno=?");
			pstmt.setInt(1, rollno);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next())
			{
				stud.setRollno(rs.getInt("rollno"));
				stud.setName(rs.getString("name"));
				stud.setAddress(rs.getString("address"));
			}
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return stud;
	}
	@Override
	public boolean registerStudentData(Student stud) throws StudentDAOException {
	
		Connection connect;
		PreparedStatement pstmt = null;
		int row = 0 ;
		try {
			connect = manager.openCon();
			 pstmt= connect.prepareStatement("insert into student(rollno,name,address) values(?,?,?)");
			
			pstmt.setInt(1, stud.getRollno());
			pstmt.setString(2, stud.getName());
			pstmt.setString(3, stud.getAddress());
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 try {
			row = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			if(row > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		
		
	}
	
}
