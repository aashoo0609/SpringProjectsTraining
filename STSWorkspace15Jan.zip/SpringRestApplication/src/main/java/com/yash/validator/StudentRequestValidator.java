package com.yash.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.yash.model.StudentRequest;

@Component
public class StudentRequestValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return StudentRequest.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		StudentRequest studReq = (StudentRequest)target;
		String rollNo = String.valueOf(studReq.getRollno());
		if(rollNo.length() < 3)
		{
			errors.reject("rollNo","RoollNo Must have atleast 4 digits..");
		}
		if(studReq.getName().length() <= 0)
		{
			errors.reject("name","Name cant be empty..");
		}
		if(studReq.getAddress().length() <= 0)
		{
			errors.reject("address","Address cant be empty..");
		}
	}

}
