package com.yash.fullAnnotaionBased;

import org.springframework.beans.factory.annotation.Value;

public class YashBean2 {
	@Value("${driver}")
	private String driver;
	
	@Override
	public String toString() {
		return "YashBean2 [driver=" + driver + "]";
	}

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public YashBean2() {
		System.out.println("Yash Bean2=========");
	}
}
