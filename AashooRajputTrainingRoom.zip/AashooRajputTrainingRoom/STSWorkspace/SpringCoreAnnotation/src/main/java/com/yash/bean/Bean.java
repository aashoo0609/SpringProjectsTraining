package com.yash.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Bean {

	@Autowired(required = true)
	@Qualifier("beanInterfImpl1")
	private BeanInterf beanInterf;
	
	private Bean()
	{
		System.out.println("====Const Parameterized Bean====");
	}
	public void x()
	{
		System.out.println("----x---");
		beanInterf.y();
	}
}
