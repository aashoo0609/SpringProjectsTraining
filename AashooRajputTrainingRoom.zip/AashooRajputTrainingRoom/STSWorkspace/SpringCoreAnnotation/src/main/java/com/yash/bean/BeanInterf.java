package com.yash.bean;

public interface BeanInterf {
	public void y();
}
