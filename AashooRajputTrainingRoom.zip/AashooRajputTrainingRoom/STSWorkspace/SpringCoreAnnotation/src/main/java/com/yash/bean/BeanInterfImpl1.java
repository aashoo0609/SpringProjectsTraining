package com.yash.bean;

import org.springframework.stereotype.Component;

@Component
public class BeanInterfImpl1  implements BeanInterf{

	public BeanInterfImpl1() {
	
		System.out.println("==========BeanInterfImpl1Const====");
		// TODO Auto-generated constructor stub
	}
	public void y() {
		// TODO Auto-generated method stub
		System.out.println("=====inter1====");
		
	}
	
	

}
