package com.yash.bean;

import org.springframework.stereotype.Component;

@Component
public class Bean7 {
	public void bean7Method()
	{
		System.out.println("======Bean7 Method====");
	}
}
