package com.yash.fullAnnotaionBased;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan(basePackages = "com.yash.*")
@Import(YashBeanConfiguration.class)
@PropertySource("classpath:/db.properties")
public class EmailConfiguration {

}
