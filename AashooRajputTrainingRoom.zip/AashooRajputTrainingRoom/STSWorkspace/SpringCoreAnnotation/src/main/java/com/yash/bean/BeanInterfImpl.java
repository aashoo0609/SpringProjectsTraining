package com.yash.bean;

import org.springframework.stereotype.Component;

@Component
public class BeanInterfImpl implements BeanInterf {

	public void y() {
		// TODO Auto-generated method stub
		System.out.println("----y----");
	}

}
