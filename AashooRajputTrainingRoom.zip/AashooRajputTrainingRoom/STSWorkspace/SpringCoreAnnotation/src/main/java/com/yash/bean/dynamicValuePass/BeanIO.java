package com.yash.bean.dynamicValuePass;

public class BeanIO {
	
	public static int someVal()
	{
		return 100;
	}

}
