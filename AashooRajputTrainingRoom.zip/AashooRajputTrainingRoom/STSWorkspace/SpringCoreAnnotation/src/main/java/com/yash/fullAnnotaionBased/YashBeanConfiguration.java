package com.yash.fullAnnotaionBased;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@ComponentScan(basePackages = "com.yash.*")
//@Import(EmailConfiguration.class)

public class YashBeanConfiguration {

	@Bean(name="yashBean2")
	public YashBean2 getYashBean(){
		return new YashBean2();
	}
}
