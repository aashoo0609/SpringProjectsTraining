package com.yash.bean.lazyloading;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
public class Bean5 {

	private Bean6 bean6;

	@Autowired
	public Bean5(@Lazy Bean6 bean6)
	{
		this.bean6 = bean6;
		System.out.println("======sBean 5 Const..");
	}
	public void bean5Method()
	{
		System.out.println("======Bean5 Method====");
		bean6.bean6Method();
		
	}

}
