package com.yash.bean.lazyloading;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
@Lazy
public class BeanA {
	
	public BeanA() {
		// TODO Auto-generated method stub
		System.out.println("=======BeanA====");
	}

}
