package com.yash.bean.dynamicValuePass;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class Beanab {
	@Value("#{10}")
	public int a;
	
	@Value("#{T(java.lang.Math).random()*100}")
	public int b;
	
	@Value("#{T(com.yash.bean.dynamicValuePass.BeanIO).someVal() * 10}")
	public int c;

	public int getA() {
		return a;
	}

	public int getB() {
		return b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public void setB(int b) {
		this.b = b;
	}

	public void setA(int a) {
		this.a = a;
	}

	
}
