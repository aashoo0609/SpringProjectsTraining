package com.yash.bean.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.bean.Bean;
import com.yash.bean.dynamicValuePass.Beanab;
import com.yash.bean.dynamicValuePass.DataSource;
import com.yash.bean.lazyloading.Bean5;
import com.yash.fullAnnotaionBased.EmailConfiguration;
import com.yash.fullAnnotaionBased.YashBean;
import com.yash.fullAnnotaionBased.YashBean2;
import com.yash.fullAnnotaionBased.YashBeanConfiguration;

public class IOCContainer
{
	public static void main(String[] args){
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Bean obj = (Bean)context.getBean("bean");
		//obj.x();
		
		
		Bean5 obj5=(Bean5)context.getBean("bean5");
		obj5.bean5Method();
		
		
		/////////dydnamic Value PAss
		Beanab objA=(Beanab)context.getBean("beanab");
		System.out.println("a:"+objA.getA());
		System.out.println("b:"+objA.getB());
		System.out.println("c:"+objA.getC());
		
		
		////Reading from Properties file
		
		DataSource objData = (DataSource)context.getBean("dataSource");
		System.out.println(objData);
		
		/////////////////////full annotation based
		ApplicationContext context2 = new AnnotationConfigApplicationContext(EmailConfiguration.class);
		/*YashBean yash=(YashBean)context2.getBean("yashBean");
		yash.setName("Ashu");
		System.out.println(yash);*/
		
		YashBean2 Yashobj = (YashBean2)context2.getBean("yashBean2");
		System.out.println(Yashobj);
		
		
	}
}
