package com.yash.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.custom.CustomHttpStatus;
import com.yash.custom.StudentError;
import com.yash.entity.Student;
import com.yash.model.StudentRegisteredResponse;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;
import com.yash.service.StudentService;
import com.yash.validator.StudentRequestValidator;

@RestController
@RequestMapping("student-app")
public class StudentController
{
	@Autowired
	private StudentService studentService;
	
	//@Autowired
	//private Validator validator = new StudentRequestValidator();
	
	@GetMapping("students")
	public ResponseEntity< List<StudentResponse>> retriveAllStudent()
	{
		List<StudentResponse> studentResponseList =  studentService.studentRetrievalService();
		System.out.println("Controller---"+studentResponseList);
		ResponseEntity<List<StudentResponse>> response = 
				new ResponseEntity<>(studentResponseList,HttpStatus.OK);
		return response;
	}
	
	@GetMapping("students/{rollNo}")
	public ResponseEntity<StudentResponse> retriveStudentByRollNo(@PathVariable("rollNo") int rollno)
	{
		StudentResponse studResponse = studentService.studentRetrievalServiceRollNo(rollno);
		ResponseEntity<StudentResponse> response = new ResponseEntity<>(studResponse,HttpStatus.OK);
		return response;
	}
	
	@PostMapping("students")
	public ResponseEntity<StudentRegisteredResponse> persistStudent(@Valid @RequestBody StudentRequest request, Errors errors)
	{
		//ValidationUtils.invokeValidator(validator, request, errors);
		
		List<StudentError> studErrorList = new ArrayList<>();
		if(errors.hasErrors())
		{
			List<ObjectError> list = errors.getAllErrors();
			for(ObjectError error : list)
			{
				StudentError studError = new StudentError();
				studError.setErrorCode(CustomHttpStatus.VALIDATION_FAILED);
				studError.setMsg(error.getDefaultMessage());
				studErrorList.add(studError);
			}
			StudentRegisteredResponse registerResponse = new StudentRegisteredResponse();
			registerResponse.setResponseMsg("Validation Error");
			registerResponse.setStudentError(studErrorList);
			//registerResponse.setResponseData(responseData);
			//return  ResponseEntity.ok().body(registerResponse).status(CustomHttpStatus.VALIDATION_FAILED.getVal()).build();
			return new ResponseEntity<StudentRegisteredResponse>(registerResponse,HttpStatus.BAD_REQUEST);
		}
		else
		{
			boolean result = studentService.studentRegistrationService(request);
			if(result)
			{
				StudentRegisteredResponse registerResponse = new StudentRegisteredResponse();
				registerResponse.setResponseMsg("Registered");
				return new ResponseEntity<StudentRegisteredResponse>(registerResponse,HttpStatus.CREATED);
			}
			else
			{
				StudentRegisteredResponse registerResponse = new StudentRegisteredResponse();
				registerResponse.setResponseMsg("Not Registered");
				return new ResponseEntity<StudentRegisteredResponse>(registerResponse,HttpStatus.CONFLICT);
			}
			
		}
	}
	
	@PutMapping("/students/{rollno}")
	public ResponseEntity<StudentResponse> updateStudent(@PathVariable("rollno") int rollno,@RequestBody StudentRequest studRequest)
	{
		StudentResponse studResponse = studentService.studentUpdateService(rollno,studRequest);
		return new ResponseEntity<StudentResponse>(studResponse,HttpStatus.OK);
	}
}
