package com.yash.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.dao.StudentDAO;
import com.yash.entity.Student;
import com.yash.exception.StudentDAOException;
import com.yash.model.StudentRequest;
import com.yash.model.StudentResponse;

@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	StudentDAO studentDAO;
	
	@Override
	public List<StudentResponse> studentRetrievalService() {
		List<StudentResponse> studentResponseList = new ArrayList<StudentResponse>();
		try {
			List<Student> studentLst = studentDAO.getAllStudents();
			for(Student student : studentLst)
			{
				StudentResponse studResponse= new StudentResponse();
				studResponse.setRollno(student.getRollno());
				studResponse.setName(student.getName());
				studResponse.setAddress(student.getAddress());
				studentResponseList.add(studResponse);
			}
		} catch (StudentDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return studentResponseList;
	}

	@Override
	public StudentResponse studentRetrievalServiceRollNo(int rollno) {
		
		StudentResponse studResponse = new StudentResponse();
		try {
			Student stud = studentDAO.getStudentByRollNo(rollno);
			
			studResponse.setRollno(stud.getRollno());
			studResponse.setName(stud.getName());
			studResponse.setAddress(stud.getAddress());
			
		} catch (StudentDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return studResponse;
	}

	@Override
	public boolean studentRegistrationService(StudentRequest studRequest) {
		
		Student student = new Student();
		student.setRollno(studRequest.getRollno());
		student.setName(studRequest.getName());
		student.setAddress(studRequest.getAddress());
		
		boolean result = false;
		try {
			result = studentDAO.registerStudentData(student);
		} catch (StudentDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public StudentResponse studentUpdateService(int rollno,StudentRequest studReq) {
		boolean result = false;
		Student stud = new Student();
		stud.setName(studReq.getName());
		stud.setAddress(studReq.getAddress());
		StudentResponse studResponse = new StudentResponse();
		try {
			Student student = studentDAO.updateStudentData(rollno,stud);
			
			studResponse.setRollno(student.getRollno());
			studResponse.setName(student.getName());
			studResponse.setAddress(student.getAddress());
		} catch (StudentDAOException e) {
			e.printStackTrace();
		}
		return studResponse;
	}

}
