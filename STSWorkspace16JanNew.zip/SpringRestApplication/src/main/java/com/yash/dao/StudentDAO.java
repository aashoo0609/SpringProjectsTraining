package com.yash.dao;

import java.sql.SQLException;
import java.util.List;

import com.yash.entity.Student;
import com.yash.exception.StudentDAOException;
import com.yash.model.StudentResponse;

public interface StudentDAO {
	public List<Student> getAllStudents() throws StudentDAOException;
	
	public Student getStudentByRollNo(int rollno) throws StudentDAOException;
	
	public boolean registerStudentData(Student stud) throws StudentDAOException;

	public Student updateStudentData(int rollno,Student stud) throws StudentDAOException;
}
